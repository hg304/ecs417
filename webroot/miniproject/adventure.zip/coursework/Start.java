 
import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class Start implements Serializable{
	
	//starts up the whole program
	public static void main(String[] args)
    {    
        startgui();
    }
	
	//creates the gui when the player starts the game
	public static void startgui()
	{
		//create a fileio object so that fileio operations can be used, in this case loading a save
		fileio io = new fileio();
		
		//creates the actual gui attributes itself and sets its layout
		JFrame f = new JFrame("Welcome!");
		f.setSize(700,500);
		JPanel panel = new JPanel();
		JPanel browsefile = new JPanel();
		JPanel start = new JPanel();
		JLabel filemessage = new JLabel("Search for a saved game:");
		JButton button = new JButton("Start Game");
		JTextField filename = new JTextField(40);
		JButton openfiles = new JButton("Search for saved games");
		f.getContentPane().add(BorderLayout.NORTH, panel);
		f.getContentPane().add(BorderLayout.CENTER, browsefile);
		f.getContentPane().add(BorderLayout.SOUTH, start);		
		JLabel label = new JLabel("Enter name:");		
		JTextField text = new JTextField(15);
		filename.setEditable(false);
		
		
		panel.add(label);
		panel.add(text);
		browsefile.add(filemessage);
		browsefile.add(filename);
		browsefile.add(openfiles);
		start.add(button);
		f.setVisible(true);
		
		//the action that is performed when the user presses this specific button, where the user is loading up a save
		openfiles.addActionListener(new ActionListener() 
		{ 
			public void actionPerformed(ActionEvent evt)
			{
				JFileChooser filechooser = new JFileChooser();
				int confirm = filechooser.showOpenDialog(null);
			
				if (confirm == JFileChooser.APPROVE_OPTION)
				{
					File savefile = filechooser.getSelectedFile();
					filename.setText(savefile.getAbsolutePath());
				}
			}
		});
		
		//action performed when the user presses this button, which is to start the game
		button.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent evt)
			{
				String charactername = text.getText();
				String savefile = filename.getText();
				
				/*nested if statement where if user has no save and no player name in the fields, game will not start, 
				if user has a save and a name in the fields, game will not start, in other cases game will start*/
				if (charactername.equals(""))
				{
					if (savefile.equals("")) 
					{
						JOptionPane.showMessageDialog(new JFrame("Note:"), "You haven't added a name for your character or you don't have a saved file!");
					}
					else
					{
						//try-catch statement where the game save is loaded and assigned to an Object ArrayList
						try 
						{
							ArrayList<Object> list = io.loadgame(savefile);
							resumegame(list);
						} 
						catch (IOException e) 
						{
							e.printStackTrace();
						} 
						catch (ClassNotFoundException e) 
						{
							e.printStackTrace();
						}
					}
				}
				else
				{
					if (!savefile.equals(""))
					{
						JOptionPane.showMessageDialog(new JFrame("Note:"), "You don't need a character name since you are using a saved file");
					}
					//if starting without save, create new game and create new rooms and player
					else
					{
						ArrayList<String> history = new ArrayList();
						Room[][] room = new Room[5][3];
						Player player = new Player(charactername);
						setup(player, room, history);
					}
				}
			}
		});
		
		
	}
	
	/*creates the gui for the game itself and passes the objects through 
	where they will be assigned so that the player can resume from where they played*/
	public static void resumegame(ArrayList<Object> list)
	{
		Player p = (Player)list.get(0);
		Room[][] r = (Room[][])list.get(1);
		int x = (int)list.get(2);
		int y = (int)list.get(3);
		ArrayList<String> history = (ArrayList<String>)list.get(4);
		JOptionPane.showMessageDialog(new JFrame("Message"), "Welcome back " + p.getname() + "!\nContinue your journey to escape the castle!");
		
		gui g = new gui(p, r, x, y, history);
	}
    
	//if user has no save, create the game gui and assign new objects to rooms meaning a new game will be started
    public static void setup(Player p, Room[][] r, ArrayList<String> history)
    {
    	int xaxis = 0;
    	int yaxis = 2;
       
        r = roomcreator(r);
        JOptionPane.showMessageDialog(new JFrame("Message"), "Welcome " + p.getname() + "!\nYou are trapped in a castle with enemies, you must escape the castle!\nYou will encounter enemies through your escape, once you encounter them, you cannot leave the room you are in!\nDefeat the enemies in the room you are in to unlock the doors!\nTo win the game, you must travel to the exit room and press the exit button when you get there!\nIf you are low on health, you can pick up food and potion buffs on the way to regain some health back.\nGo!");
        gui g = new gui(p, r, xaxis, yaxis, history);
    }
    
    //creates the rooms and assigns their attributes
    public static Room[][] roomcreator(Room[][] r)
    {
    	for(int i=0; i < r.length; i++)
    	{
    		for (int j=0; j < r[0].length; j++)
    		{
        		r[i][j] = new Room();
    		}
    	}
    	
    	for (int i=0; i < r.length; i++)
        {
    		for (int j=0; j < r[0].length; j++)
    		{
    			r[i][j].randomgenerator(r[i][j]);
    		}
            
        }
    	
    	
    	return r;
    }



}
