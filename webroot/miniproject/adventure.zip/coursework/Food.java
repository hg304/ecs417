 

import java.io.Serializable;

public class Food extends Buff implements Serializable{

	//declare instance variables
	private double health;
	private String name;

	//Constructor for food buff
    public Food()
    {
        name = "Food";
        health = 35.0;
    }

    //methods of food buff, overrides the Buff class methods
    @Override
    public double gethealth()
    {
        return health;
    }
    
    public String getname()
    {
    	return name;
    }

}
