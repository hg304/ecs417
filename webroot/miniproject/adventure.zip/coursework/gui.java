 

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;

public class gui implements ActionListener, Serializable {
    
    //declare instance variables
    private JButton up;
    private JButton down;
    private JButton left;
    private JButton right;
    private JButton weak;
    private JButton med;
    private JButton strong;
    private JButton potion;
    private JButton food;
    private JButton exit;
    private JButton save;
    private JPanel panel;
    private JTextArea text;
    private Room[][] r;
    private Player p;
    private int xaxis;
    private int yaxis;
    private Enemy e;
    private ArrayList<String> history;
    
    //constructor for gui, creates the gui and assigns the 4 main variables used for the game
    public gui(Player player, Room[][] room, int x, int y, ArrayList<String> list)
    {
        //the assigned values for the four will be determined whether the player has a saved game or starting a new game
        p = player;
        r = room;
        xaxis = x;
        yaxis = y;
        history = list;
        
        //rest of the code creates the gui and lays it out
        JFrame f = new JFrame("Adventure Game");
        f.setSize(1050,700);
        
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        createpanel();
        
        
        text = new JTextArea();
        
        f.getContentPane().add(BorderLayout.CENTER, text);
        f.getContentPane().add(BorderLayout.SOUTH, panel);
        f.setVisible(true);
        text.setEditable(false);
        
        text.setText(displaymap());
    }
    
    //method that will display the action history of the player 
    public String displayhistory()
    {
        
        String concat = "Your action history:\n";
        for (int i = history.size() - 1; i >= 0; i--)
        {
            concat = concat + history.get(i) + "\n";
        }
            
        return concat;
    }
    
    //method which will display the map which has been created by the Room class
    public String displaymap()
    {
        String actionhistory = displayhistory();
        
        if (xaxis == 4 && yaxis == 1)
        {
            return actionhistory + r[xaxis][yaxis].showmap(xaxis, yaxis) + "\nHealth: " + p.gethealth() + "\n" + r[xaxis][yaxis].showdetails() + "The Exit Room\n\n" + r[xaxis][yaxis].showlist() + "\nExit the Castle";
        }
        else
        {
            return actionhistory + r[xaxis][yaxis].showmap(xaxis, yaxis) + "\nHealth: " + p.gethealth() + "\n" + r[xaxis][yaxis].showdetails() + "\n" + r[xaxis][yaxis].showlist();
        }
        
    }
    
    //shows what's in the current room and asks the user what they wish to do
    public String showinfo()
    {
        return r[xaxis][yaxis].showdetails() + "\n" + r[xaxis][yaxis].showlist();
    }
    
    //methods that handles all the actions for each button when pressed
    public void actionPerformed(ActionEvent evt)
    {
        //if the button pressed is up, move to the room above, if there is no room above then inform user they can't go any further
        if (evt.getSource() == up)
        {
            try {
                if (r[xaxis][yaxis].unlockroom() == true)
                {
                    yaxis += 1;
                    text.setText(displaymap());
                }
                else
                {
                    text.append("\n\nSlay the enemies if you want to move to another room!" + "\n" + showinfo());
                }
            }
    
            catch (ArrayIndexOutOfBoundsException e) {
                text.append("\nThere are no rooms beyond where you are going!");
                yaxis -= 1;
            }
        }
        
        //if the button pressed is down, move to the room below, if there is no room below then inform user they can't go any further
        else if (evt.getSource() == down)
        {
            try {
                if (r[xaxis][yaxis].unlockroom() == true)
                {
                    yaxis -= 1;
                    text.setText(displaymap());
                }
                else
                {
                    text.append("\n\nSlay the enemies if you want to move to another room!" + "\n" + showinfo());
                }
            }
            
            catch (ArrayIndexOutOfBoundsException e) {
                text.append("\nThere are no rooms beyond where you are going!");
                yaxis += 1;
            }
        }
        
        //if the button pressed is left, move to the room to the left, if there is no room to the left then inform user they can't go any further
        else if (evt.getSource() == left)
        {
            try {
                if (r[xaxis][yaxis].unlockroom() == true)
                {
                    xaxis -= 1;
                    text.setText(displaymap());
                }
                else
                {
                    text.append("\n\nSlay the enemies if you want to move to another room!" + "\n" + showinfo());
                }
            }
            
            catch (ArrayIndexOutOfBoundsException e) {
                text.append("\nThere are no rooms beyond where you are going!");
                xaxis += 1;
            }
        }
        
        //if the button pressed is right, move to the room to the right, if there is no room to the right then inform user they can't go any further
        else if (evt.getSource() == right)
        {
            try {
                if (r[xaxis][yaxis].unlockroom() == true)
                {
                    xaxis += 1;
                    text.setText(displaymap());
                }
                else
                {
                    text.append("\n\nSlay the enemies if you want to move to another room!" + "\n" + showinfo());
                }
            }
            
            catch (ArrayIndexOutOfBoundsException e) {
                text.append("\nThere are no rooms beyond where you are going!");
                xaxis -= 1;
            }
        }
        
        //if the button pressed is weak, then attack the weak enemy, if there's no weak enemy then inform user that this action is not possible
        else if (evt.getSource() == weak)
        {
            if (r[xaxis][yaxis].getdetails("weak") == null)
            {
                text.append("\n\nThe type of enemy you picked is not in this room!" + "\n" + showinfo());
            }
            else
            {
                e = r[xaxis][yaxis].getdetails("weak");
                
                text.setText(r[xaxis][yaxis].fight(p, e));
                history.add("Defeated " + e.getname() + " enemy");
                r[xaxis][yaxis].removeitem("weak");
                text.setText(displaymap());
            }
        }
        
        //if the button pressed is medium, then attack the medium enemy, if there's no medium enemy then inform user that this action is not possible
        else if (evt.getSource() == med)
        {
            if (r[xaxis][yaxis].getdetails("medium") == null)
            {
                text.append("\n\nThe type of enemy you picked is not in this room!" + "\n" + r[xaxis][yaxis].showdetails() + "\n" + r[xaxis][yaxis].showlist());
            }
            else
            {
                e = r[xaxis][yaxis].getdetails("medium");
                
                text.setText(r[xaxis][yaxis].fight(p, e));
                history.add("Defeated " + e.getname() + " enemy");
                r[xaxis][yaxis].removeitem("medium");
                text.setText(displaymap());
            }
        }
        
        //if the button pressed is strong, then attack the strong enemy, if there's no strong enemy then inform user that this action is not possible
        else if (evt.getSource() == strong)
        {
            if (r[xaxis][yaxis].getdetails("strong") == null)
            {
                text.append("\n\nThe type of enemy you picked is not in this room!" + "\n" + r[xaxis][yaxis].showdetails() + "\n" + r[xaxis][yaxis].showlist());
            }
            else
            {
                e = r[xaxis][yaxis].getdetails("strong");
                
                text.setText(r[xaxis][yaxis].fight(p, e));
                history.add("Defeated " + e.getname() + " enemy");
                r[xaxis][yaxis].removeitem("strong");
                text.setText(displaymap());
            }
        }
        
        //if button pressed is potion, then consume potion buff, if potion is not in room then inform user they cannot do this action
        else if (evt.getSource() == potion)
        {
            if (r[xaxis][yaxis].checkbuff("Potion") == null)
            {
                text.append("\n\nThere is no potion in this room!" + "\n" + r[xaxis][yaxis].showdetails() + "\n" + r[xaxis][yaxis].showlist());
            }
            else
            {
                double health = r[xaxis][yaxis].gethealth();
                history.add("Consumed " + r[xaxis][yaxis].getbuffname() + " buff");
                r[xaxis][yaxis].removeitem("potion");
                p.increasehealth(health);
                text.setText(displaymap());
            }
        }
        
        //if button pressed is food, then consume food buff, if food is not in room then inform user they cannot do this action
        else if (evt.getSource() == food)
        {
            if (r[xaxis][yaxis].checkbuff("Food") == null)
            {
                text.append("\n\nThere is no food in this room!" + "\n" + r[xaxis][yaxis].showdetails() + "\n" + r[xaxis][yaxis].showlist());
            }
            else
            {
                double health = r[xaxis][yaxis].gethealth();
                history.add("Consumed " + r[xaxis][yaxis].getbuffname() + " buff");
                r[xaxis][yaxis].removeitem("food");
                p.increasehealth(health);
                text.setText(displaymap());
            }
        }
        
        //if button pressed is save game, then save the game by passing the player, rooms, x and y axis variables to the save() method in the fileio class
        else if (evt.getSource() == save)
        {
            JOptionPane.showMessageDialog(new JFrame("Message"), p.getname() + ", you are going to save your game.\nWhen you are saving, please ensure that you save it as a .txt file so that we are able to read the file once you load the save at the start of the game again.");
            JFileChooser saver = new JFileChooser("Save");

            int confirm = saver.showSaveDialog(null);
            
            if (confirm == JFileChooser.APPROVE_OPTION)
            {
                File savefile = saver.getSelectedFile();
                String filepath = savefile.getAbsolutePath();
                fileio io = new fileio();
                try 
                {
                    io.save(p, r, xaxis, yaxis, history, filepath);
                } 
                catch (IOException e) 
                {
                    e.printStackTrace();
                }
            }
        }
        
        //if button pressed is exit, then user exits the castle and they win the game, if they are not in the exact x and y axis values then they will not be able to exit the castle
        else
        {
            if (xaxis == 4 && yaxis == 1)
            {
                JOptionPane.showMessageDialog(new JFrame("Congrats!"), "You won! You have escaped the castle!");
                System.exit(0);
            }
            else
            {
                JOptionPane.showMessageDialog(new JFrame("Message"), "You have not approached the exit room yet!");
            }
        }
    }
    
    //method which creates the panel for the buttons for the gui and adds action listeners for them
    public void createpanel()
    {
        panel = new JPanel();
        
        up = new JButton("Up");
        down = new JButton("Down");
        left = new JButton("Left");
        right = new JButton("Right");
        weak = new JButton("Weak");
        med = new JButton("Medium");
        strong = new JButton("Strong");
        potion = new JButton("Potion");
        food = new JButton("Food");
        exit = new JButton("Exit");
        save = new JButton("Save Game");
        
        panel.add(up);
        panel.add(down);
        panel.add(left);
        panel.add(right);
        panel.add(weak);
        panel.add(med);
        panel.add(strong);
        panel.add(potion);
        panel.add(food);
        panel.add(exit);
        panel.add(save);
        
        up.addActionListener(this);
        down.addActionListener(this);
        left.addActionListener(this);
        right.addActionListener(this);
        weak.addActionListener(this);
        med.addActionListener(this);
        strong.addActionListener(this);
        potion.addActionListener(this);
        food.addActionListener(this);
        exit.addActionListener(this);
        save.addActionListener(this);
    }
    
}
