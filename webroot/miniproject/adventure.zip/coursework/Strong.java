 

import java.io.Serializable;

public class Strong extends Enemy implements Serializable{
	
	//declare instance variables
	private String name;
	private double health;

	//Constructor for strong enemy
    public Strong()
    {
        name = "Strong";
        health = 75.0;
    }
    
    //methods for strong enemy, overrides the methods at Enemy class
    @Override
    public void decreasehealth(double hhealth)
    {
        this.health -= hhealth;
    }
    @Override
    public double gethealth()
    {
    	return this.health;
    }
    @Override
    public String getname()
    {    	return this.name;
    }
    

}
