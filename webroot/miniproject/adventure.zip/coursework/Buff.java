 

import java.io.Serializable;

public class Buff implements Serializable{
	
	//declare instance variables
	private String name;
	private double health;
    
	//methods for Buff class, these are overriden by subclass methods
    public double gethealth()
    {
    	return health;
    }
    
    public String getname()
    {
    	return name;
    }

}
