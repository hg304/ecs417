  
import java.io.Serializable;

public class Enemy implements Serializable{
	
	//declare instance variables
	private String name;
	private double health;
    
	//methods for Enemy class, these are overridden by subclass methods
    public String getname()
    {
        return name;
    }
    
    public void decreasehealth(double hhealth)
    {
    	health -= hhealth;
    }
    
    public double gethealth()
    {
    	return health;
    }
    
    

}
