 

import java.io.Serializable;

public class Potion extends Buff implements Serializable{

	private double health;
	private String name;

	//Constructor for potion buff
    public Potion()
    {
        name = "Potion";
        health = 75.0;
    }

    //methods used for potion buff, overrides the methods of the Buff class
    @Override
    public double gethealth()
    {
        return health;
    }
    @Override
    public String getname()
    {
    	return name;
    }

}
