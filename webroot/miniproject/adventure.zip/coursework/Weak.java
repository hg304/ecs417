 

import java.io.Serializable;

public class Weak extends Enemy implements Serializable{
	
	//declare instance variables
	private String name;
	private double health;
    
	//Constructor for weak enemy
	public Weak()
    {
        name = "Weak";
        health = 25.0;
    }
	
	//methods for weak enemy, overrides the methods at Enemy class
    @Override
    public void decreasehealth(double hhealth)
    {
        this.health -= hhealth;
    }
    @Override
    public double gethealth()
    {
    	return this.health;
    }
    @Override
    public String getname()
    {
    	return this.name;
    }
    

}
