 
import java.io.*;
import java.util.ArrayList;

public class fileio implements Serializable
{

	//Constructor needed in order to utilize the methods for file i/o, nothing needs to be inside as it is not necessary
	public fileio()
	{

	}
	
	//save method, saves the current stage of the game of what has been played
	public void save(Player p, Room[][] r, int x, int y, ArrayList<String> history, String path) throws IOException
	{
		ArrayList<Object> list = new ArrayList<Object>();
		list.add(p);
		list.add(r);
		list.add(x);
		list.add(y);
		list.add(history);
		
		ObjectOutputStream saveplayer = new ObjectOutputStream(new FileOutputStream(path));
		saveplayer.writeObject(list);
		saveplayer.close();	
	}
	
	//method which loads up a saved game so that it can be played back at the point when it was saved
	public ArrayList<Object> loadgame(String path) throws IOException, ClassNotFoundException
	{
		ArrayList<Object> list = null;
		ObjectInputStream pl = new ObjectInputStream(new FileInputStream(path));
		list = (ArrayList<Object>) pl.readObject();
		pl.close();
		
		return list;
	}


}
