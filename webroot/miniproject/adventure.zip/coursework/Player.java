 

import java.io.Serializable;

public class Player implements Serializable{
	private String name;
    private double health;
    
    //Constructor for the Player, assigning their name and start health
    public Player(String nname)
    {
        name = nname;
        health = 100.0;
    }
    

    //methods of the player which affects health and gets their name
    public void increasehealth(double hhealth)
    {
        health += hhealth;
    }
    
    public void decreasehealth(double hhealth)
    {
        health -= hhealth;
    }
    
    public double gethealth()
    {
        return health;
    }
    
    public String getname()
    {
        return name;
    }

}
