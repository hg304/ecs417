 

import java.io.Serializable;

public class Medium extends Enemy implements Serializable{
	
	//declare instance variables
	private String name;
	private double health;
    
	//Constructor for medium enemy
    public Medium()
    {
    	name = "Medium";
        health = 50.0; 
    }
    
    //methods for medium enemy, overrides the methods at Enemy class
    @Override
    public void decreasehealth(double hhealth)
    {
        this.health -= hhealth;
    }
    @Override
    public double gethealth()
    {
    	return this.health;
    }
    @Override
    public String getname()
    {
    	return this.name;
    }

}
