 
import java.io.Serializable;
import java.util.*;
import javax.swing.*;

	public class Room implements Serializable{
	
	//declare instance variables
	private Buff buff;
    private Enemy weak;
    private Enemy med;
    private Enemy strong;
    
    //Constructor for the Room object, everything initially assigned to null
    public Room()
    {
    	buff = null;
    	weak = null;
    	med = null;
    	strong = null;
    }
    
    //adds the objects in each specific room depending on the two random numbers that have been passed through from the random generator
    public Room additems(Room r, int choice, int choice2)
    {
        if (choice == 1)
        {
            buff = new Food();
        }
        if (choice == 2)     
        {
            buff = new Potion();
        }
        if (choice == 3)
        {
            weak = new Weak();
        }
        if (choice == 4)
        {
            med = new Medium();
        }
        if (choice == 5)
        {
            strong = new Strong();
        }
        
        if (choice2 == 1)
        {
            buff = new Food();
        }
        if (choice2 == 2)     
        {
            buff = new Potion();
        }
        if (choice2 == 3)
        {
            weak = new Weak();
        }
        if (choice2 == 4)
        {
            med = new Medium();
        }
        if (choice2 == 5)
        {
            strong = new Strong();
        }
        
        return r;
        
    }
    
    //randomly assigns two numbers between 1 to 5 which determines what kind of object will be added to the current room chosen
    public void randomgenerator(Room r)
    {
       Random ra = new Random();
       int random = ra.nextInt(5) + 1; 
       int random2 = ra.nextInt(5) + 1;
       
       r = additems(r, random, random2);    
    }
    
    //method which checks if the buff that has been picked is available in the room the player is at
    public Buff checkbuff(String b)
    {
    	if (b.equals(buff.getname()) && buff != null)
    	{
    		return buff;
    	}
    	else
    	{
    		return null;
    	}
    }
    
    //grabs the information of the enemy that has been chosen
    public Enemy getdetails(String pick)
    {
    	if (pick.equals("weak"))
    	{
    		return weak;
    	}
    	else if (pick.equals("medium"))
    	{
    		return med;
    	}
    	else
    	{
    		return strong;
    	}
    }
    
    //displays to the player what is inside the current room they are at
    public String showdetails()
    {
    	String concat = "This room contains:\n";
    	if (buff != null)
    	{
    		concat = concat + buff.getname() + "\n";
    	}
    	if (weak != null)
    	{
    		concat = concat + weak.getname() + " Enemy\n";
    	}
    	if (med != null)
    	{
    		concat = concat + med.getname() + " Enemy\n";
    	}
    	if (strong != null)
    	{
    		concat = concat + strong.getname() + " Enemy\n";
    	}
    	return concat;
    	
    }
    
    //creates a message and asks the user what they wish to do inside the room they are at
    public String showlist()
    {
    	String concat = "What do you wish to do?\n";
        if (buff != null)
        {
        	concat = concat + "Consume " + buff.getname() + "\n";
        }
        if (weak != null)
        {
        	concat = concat + "Attack the " + weak.getname() + " enemy\n";
        }
        if (med != null)
        {
        	concat = concat + "Attack the " + med.getname() + " enemy\n";
        }
        if (strong != null)
        {
        	concat = concat + "Attack the " + strong.getname() + " enemy\n";
        }
        return concat + "Move either left, right, up or down to the next room";
    }
    
    //gets the health attribute of the buff that has been chosen
    public double gethealth()
    {
    	return buff.gethealth();
    	
    }
    
    public String getbuffname()
    {
    	return buff.getname();
    }
    
    /*method which performs the fighting of the game; two random numbers assigned between 1 to 10 
    and are the amount of health lost for the player and enemy each respectively, 
    will keep going until one of the two loses all their health*/
    public String fight(Player p, Enemy e)
    {
    	String message = "Fighting the enemy...\n";
    	while (p.gethealth() > 0.0 && e.gethealth() > 0.0)
    	{
    		Random ra = new Random();
    		int random1 = ra.nextInt(10) + 1;
    		int random2 = ra.nextInt(10) + 1;
    		p.decreasehealth(random1);
    		e.decreasehealth(random2);   			
    	}
    	if (p.gethealth() <= 0.0)
    	{
    		
    		JOptionPane.showMessageDialog(new JFrame("Game over!"), "You died!");
    		System.exit(0);
    	}
    	else
    	{
    		message = message + "You have slain the enemy!\nHealth: " + p.gethealth() + "\n";
    	}
    	return message;
    }
    
    //method which will unlock the room the player is currently in depending if there are any enemies in the room
    public boolean unlockroom()
    {
    	if (weak != null || med != null || strong != null)
    	{
    		return false;
    	}
    	else
    	{
    		return true;
    	}
    }
    
    /*method which removes the object from the room once picked, if an enemy dies 
    or a buff is consumed, they are removed from the room*/
    public void removeitem(String pick)
    {
    	if (pick.equals("food") || pick.equals("potion"))
    	{
    		buff = null;
    	}
    	if (pick.equals("weak"))
    	{
    		weak = null;
    	}
    	if (pick.equals("medium"))
    	{
    		med = null;
    	}
    	if (pick.equals("strong"))
    	{
    		strong = null;
    	}
    }
    
    //displays the map of the game and shows the current location of the player
    public String showmap(int x, int y)
    {
    	if (x == 0 && y == 2)
    	{
    		String concat = "";
    		concat = concat + " ___ ___ ___ ___ ___\n";
    		concat = concat + "|_._|___|___|___|___|\n";
    		concat = concat + "|___|___|___|___|___|<- Exit\n";
    		concat = concat + "|___|___|___|___|___|\n";
    		concat = concat + "The dot shows your location right now";
    		return concat;
    	}
    	else if (x == 1 && y == 2)
    	{
    		String concat = "";
    		concat = concat + " ___ ___ ___ ___ ___\n";
    		concat = concat + "|___|_._|___|___|___|\n";
    		concat = concat + "|___|___|___|___|___|<- Exit\n";
    		concat = concat + "|___|___|___|___|___|\n";
    		concat = concat + "The dot shows your location right now";
    		return concat;
    	}
    	else if (x == 2 && y == 2)
    	{
    		String concat = "";
    		concat = concat + " ___ ___ ___ ___ ___\n";
    		concat = concat + "|___|___|_._|___|___|\n";
    		concat = concat + "|___|___|___|___|___|<- Exit\n";
    		concat = concat + "|___|___|___|___|___|\n";
    		concat = concat + "The dot shows your location right now";
    		return concat;
    	}
    	else if (x == 3 && y == 2)
    	{
    		String concat = "";
    		concat = concat + " ___ ___ ___ ___ ___\n";
    		concat = concat + "|___|___|___|_._|___|\n";
    		concat = concat + "|___|___|___|___|___|<- Exit\n";
    		concat = concat + "|___|___|___|___|___|\n";
    		concat = concat + "The dot shows your location right now";
    		return concat;
    	}
    	else if (x == 4 && y == 2)
    	{
    		String concat = "";
    		concat = concat + " ___ ___ ___ ___ ___\n";
    		concat = concat + "|___|___|___|___|_._|\n";
    		concat = concat + "|___|___|___|___|___|<- Exit\n";
    		concat = concat + "|___|___|___|___|___|\n";
    		concat = concat + "The dot shows your location right now";
    		return concat;
    	}
    	else if (x == 0 && y == 1)
    	{
    		String concat = "";
    		concat = concat + " ___ ___ ___ ___ ___\n";
    		concat = concat + "|___|___|___|___|___|\n";
    		concat = concat + "|_._|___|___|___|___|<- Exit\n";
    		concat = concat + "|___|___|___|___|___|\n";
    		concat = concat + "The dot shows your location right now";
    		return concat;
    	}
    	else if (x == 1 && y == 1)
    	{
    		String concat = "";
    		concat = concat + " ___ ___ ___ ___ ___\n";
    		concat = concat + "|___|___|___|___|___|\n";
    		concat = concat + "|___|_._|___|___|___|<- Exit\n";
    		concat = concat + "|___|___|___|___|___|\n";
    		concat = concat + "The dot shows your location right now";
    		return concat;
    	}
    	else if (x == 2 && y == 1)
    	{
    		String concat = "";
    		concat = concat + " ___ ___ ___ ___ ___\n";
    		concat = concat + "|___|___|___|___|___|\n";
    		concat = concat + "|___|___|_._|___|___|<- Exit\n";
    		concat = concat + "|___|___|___|___|___|\n";
    		concat = concat + "The dot shows your location right now";
    		return concat;
    	}
    	else if (x == 3 && y == 1)
    	{
    		String concat = "";
    		concat = concat + " ___ ___ ___ ___ ___\n";
    		concat = concat + "|___|___|___|___|___|\n";
    		concat = concat + "|___|___|___|_._|___|<- Exit\n";
    		concat = concat + "|___|___|___|___|___|\n";
    		concat = concat + "The dot shows your location right now";
    		return concat;
    	}
    	else if (x == 4 && y == 1)
    	{
    		String concat = "";
    		concat = concat + " ___ ___ ___ ___ ___\n";
    		concat = concat + "|___|___|___|___|___|\n";
    		concat = concat + "|___|___|___|___|_._|<- Exit\n";
    		concat = concat + "|___|___|___|___|___|\n";
    		concat = concat + "The dot shows your location right now";
    		return concat;
    	}
    	else if (x == 0 && y == 0)
    	{
    		String concat = "";
    		concat = concat + " ___ ___ ___ ___ ___\n";
    		concat = concat + "|___|___|___|___|___|\n";
    		concat = concat + "|___|___|___|___|___|<- Exit\n";
    		concat = concat + "|_._|___|___|___|___|\n";
    		concat = concat + "The dot shows your location right now";
    		return concat;
    	}
    	else if (x == 1 && y == 0)
    	{
    		String concat = "";
    		concat = concat + " ___ ___ ___ ___ ___\n";
    		concat = concat + "|___|___|___|___|___|\n";
    		concat = concat + "|___|___|___|___|___|<- Exit\n";
    		concat = concat + "|___|_._|___|___|___|\n";
    		concat = concat + "The dot shows your location right now";
    		return concat;
    	}
    	else if (x == 2 && y == 0)
    	{
    		String concat = "";
    		concat = concat + " ___ ___ ___ ___ ___\n";
    		concat = concat + "|___|___|___|___|___|\n";
    		concat = concat + "|___|___|___|___|___|<- Exit\n";
    		concat = concat + "|___|___|_._|___|___|\n";
    		concat = concat + "The dot shows your location right now";
    		return concat;
    	}
    	else if (x == 3 && y == 0)
    	{
    		String concat = "";
    		concat = concat + " ___ ___ ___ ___ ___\n";
    		concat = concat + "|___|___|___|___|___|\n";
    		concat = concat + "|___|___|___|___|___|<- Exit\n";
    		concat = concat + "|___|___|___|_._|___|\n";
    		concat = concat + "The dot shows your location right now";
    		return concat;
    	}
    	else
    	{
    		String concat = "";
    		concat = concat + " ___ ___ ___ ___ ___\n";
    		concat = concat + "|___|___|___|___|___|\n";
    		concat = concat + "|___|___|___|___|___|<- Exit\n";
    		concat = concat + "|___|___|___|___|_._|\n";
    		concat = concat + "The dot shows your location right now";
    		return concat;
    	}
    }

}
